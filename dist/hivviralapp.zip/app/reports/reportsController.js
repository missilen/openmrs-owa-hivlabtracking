/**
 * Created by trungnguyen on 11/29/16.
 */
app.controller('reportsController', ['$scope', '$rootScope','$modal','$routeParams','$location','$route','$log','$http', function($scope, $rootScope, $modal,$routeParams,$location, $route,$log,$http) {


}]);







